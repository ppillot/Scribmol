Clazz.declarePackage ("JU");
c$ = Clazz.declareType (JU, "GZIPInputStream");
